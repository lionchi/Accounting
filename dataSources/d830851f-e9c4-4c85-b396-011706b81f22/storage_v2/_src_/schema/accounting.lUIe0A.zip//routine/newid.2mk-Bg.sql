create function newid()
  returns varchar(32)
  return replace(uuid(), '-', '');

